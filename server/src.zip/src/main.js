import express from 'express';
import path from 'path';
import morgan from 'morgan'; // HTTP REQUEST LOGGER
import bodyParser from 'body-parser'; // PARSE HTML BODY
import session from 'express-session';
import dbConfig from '../config/db_config';
import cors from 'cors';

import api from './routes';
var MySQLStore = require('express-mysql-session')(session);
var passport = require('passport')
var LocalStrategy = require('passport-local').Strategy;

const port = 3001;

const app = express();
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json())
app.use(cors()); //allow cross domain
app.use(session({
    secret: 'react1231$1$234',
    resave: false,
    saveUninitialized: true,
    store: new MySQLStore(dbConfig)
}));


app.use('/', express.static(path.join(__dirname, '../../public')));
app.use('/api', api);
app.use(morgan('dev'));


app.get('/hello', (req, res) => {
    return res.send('Hello CodeLab');
});

app.listen(port, () => {
    console.log('Express is listening on port', port);
});
