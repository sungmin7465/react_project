import express from 'express';
import mysql from 'mysql';
import dbConfig from '../../config/db_config';
import bkfd2Password from 'pbkdf2-password';

const router = express.Router();
const conn = mysql.createConnection(dbConfig);
let hasher = bkfd2Password();
var passport = require('passport')

/*
    ACCOUNT SIGNUP: POST /api/account/signup
    BODY SAMPLE: { "username": "test", "password": "test" }
    ERROR CODES:
        1: BAD USERNAME
        2: BAD PASSWORD
        3: USERNAM EXISTS
        4: LOGIN FAILED
        5: SESSION DATA UNDEFINED
        6: BAD DISPLAYNAME
        7: No ARTICLE
        8: PERMISSION DENY
        99: DB ERROR

*/
// 400 Bad Request 409 Conflict 503 ServiceUnavailable 200 OK

router.post('/signup', (req, res) => {
    // CHECK USERNAME FORMAT
    let usernameRegex = /^[a-z0-9]+$/;

    if(!usernameRegex.test(req.body.userId)) {
        return res.status(400).json({
            error: "BAD USERNAME",
            code: 1
        });
    }
    // CHECK PASS LENGTH
    if(req.body.password.length < 4 || typeof req.body.password !== "string") {
        return res.status(400).json({
            error: "BAD PASSWORD",
            code: 2
        });
    }

    if(req.body.displayName.length < 2) {
        return res.status(400).json({
            error: "BAD DISPLAYNAME",
            code: 6
        });
    }

    hasher({password:req.body.password}, function(err, pass, salt, hash){
      var user = {
        authId:'local:'+req.body.userId,
        username:req.body.userId,
        password:hash,
        salt:salt,
        displayName:req.body.displayName
      };
      var sql = 'INSERT INTO users SET ?';
      conn.query(sql, user, function(err, results){
        if(err){
          if( err.code === 'ER_DUP_ENTRY'){
            return res.status(409).json({
                error: "USERNAME EXISTS",
                code: 3
            });

          } else{
            return res.status(409).json({
                error: "DB ERROR",
                code: 99
            });
          }
        }
        else {
          return res.status(200).json({ success: true });
        }
      });
    });

});

router.post('/login', passport.authenticate('local',
    { successRedirect: '/',
      failureFlash: true }));

// router.post('/login', (req, res) => {
//
//   var authId = 'local:'+req.body.userId;
//   var password = req.body.password;
//
//   var sql = "SELECT * FROM `users` WHERE `authId`=?";
//   conn.query(sql, [authId],function (err, rows, fields) {
//     if (err){
//       return res.status(503).json({
//           error: "DB ERROR",
//           code: 99
//       });
//     }
//     if(rows.length===0){
//       return res.status(409).json({
//         error: "LOGIN FAILED",
//         code: 4
//       });
//     }
//     return hasher({password:password, salt:rows[0].salt}, function(err, pass, salt, hash){
//       console.dir(hash)
//       if(hash === rows[0].password){
//         let session = req.session;
//
//         session.loginInfo = {
//             authId: authId,
//             displayName: rows[0].displayName
//         };
//
//         res.json({ user: session.loginInfo });
//
//       } else {
//         return res.status(409).json({
//             error: "LOGIN FAILED",
//             code: 4
//         });
//       }
//     });
//   });
// });

router.get('/getinfo', (req, res) => {
    if(typeof req.session.loginInfo === "undefined") {
        return res.status(409).json({
            error: "SESSION DATA UNDEFINED",
            code: 5
        });
    }
    res.status(200).json({ user: req.session.loginInfo });
});

router.post('/logout', (req, res) => {
    req.session.destroy(err => { if(err) throw err; });
    return res.status(200).json({ sucess: true });
});
export default router;
